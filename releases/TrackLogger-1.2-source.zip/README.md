# Track Logger 1.2

A small Android app that records the raw signals behind the corner figure (GPS speed, accelerometer, gyro) and a
Python script that turns the recording into speed, brake/throttle, steering and g-g traces, lap times and a
per-corner table.

**Status: built, signature-checked and tested on a PC against a simulated phone. It has never run on a real phone.**Test it before the track day (section 3). The things that can differ on a real phone are listed in section 7.

## 1. Install the app

1. Get `TrackLogger-1.2.apk` onto the phone (Drive, email to yourself, USB, WhatsApp "saved messages"...).
2. Open it. Android asks to allow "Install unknown apps" for the app you opened it from. Allow that.
3. Play Protect may say "unrecognised developer". Tap *Install anyway*. The app is signed with a key made on the build
   machine, not by Google Play, so this warning is expected. (Google's developer-verification rules went live on
   30 Sep 2026 for Indonesia, Singapore and Thailand, and some reports add Brazil. Google says the rest of the world
   follows during 2027. Malaysia was not on the list when I checked on 12 Oct 2026. If your phone refuses the install
   anyway, `adb install TrackLogger-1.2.apk` from a computer still works, and Google's "advanced flow" lets you
   continue after a one-time setup.)
   On Samsung phones, *Auto Blocker* (Settings > Security and privacy) stops all sideloaded installs: switch it off first.
4. Open **Track Logger**. Tap START. Allow **Precise** location (not "Approximate") and notifications, then tap START again.
   If you have refused twice, Android stops asking and the app opens its Settings page instead: Permissions >
   Location > Allow, and turn on *Use precise location*.
5. Tap *Battery: allow background* and set the app to **Unrestricted** (Samsung: Settings > Apps > Track Logger >
   Battery > Unrestricted). On Xiaomi, Oppo, Vivo, Honor and OnePlus also switch on *Autostart* for the app and lock it
   in the recent-apps screen. Those phones may kill an app the moment it is swiped out of recents.
   **Never swipe the app away while recording.**

Needs Android 10 or later, a GPS and an accelerometer. A gyro is strongly recommended (almost every phone has one).
The app has no internet permission: the data stays on the phone unless you share the file yourself.

## 2. What it records

One CSV per session in `Downloads/TrackLogger/session_YYYYMMDD_HHMMSS.csv`, about 0.5 MB per minute:

| row | content |
|---|---|
| `A` | accelerometer, 3 axes in phone coordinates, about 100 Hz |
| `G` | gyroscope, 3 axes in phone coordinates, about 100 Hz |
| `L` | GPS fix: lat, lon, altitude, Doppler speed, bearing, accuracies, delay (about 1 Hz on most phones) |
| `S` | satellites visible / used, once a second |
| `E` | `START`, `CAL` (the stationary calibration and its result), `CALFAIL`, `STOP` |
| `K` | clock check: arrival time minus event time, every 30 s |

Times are microseconds since START on one clock. A missing GPS value is `-1` (altitude `-9999`). `L` rows are written when
the fix arrives, so they can sit slightly out of order and the first can have a small negative time: the analysis sorts them.

Nothing is processed on the phone. A copy is also kept in the app's private folder; *Re-export last session* copies the
newest one to Downloads again if anything went wrong, and *Share last export* sends it to Drive, email, WhatsApp...

## 3. Test it tonight (10 minutes)

1. Fix the phone in the car the way you will tomorrow. Any angle is fine, but it must not move.
2. Park somewhere with open sky. Press START (allow permissions, press START again). Keep the car still for the
   5 second countdown. The screen counts down STAY STILL, then shows REC. An idling engine is fine.
3. Still parked: the screen should show a GPS fix with a sensible accuracy (a few metres), IMU accel and gyro at
   roughly 100 Hz (or more), and a vertical g near 1.0. Then press the power button to lock the phone, wait one minute,
   and unlock it. The counters (A, G, GPS) must have kept growing, by about 6k, 6k and 60.
4. Drive a loop on public roads, legally, with a few accelerations, brakings and turns. A few stretches above 30 km/h
   help the analysis. Do not touch or watch the phone while driving. (A passenger can watch the horizontal g
   rise in turns and the speed follow the car.)
5. Park, press STOP & SAVE. The screen says SAVING... and then SAVED, with the file name.
6. Look for the file: Files app > Downloads > TrackLogger.
7. Optional but best: copy the CSV to a computer and run the analysis (section 5). A good test shows
   `Forward axis ... R2` near 1.00. If you send me the file tonight I will check it.

If anything fails, tell me what the screen says. Do not wait until the morning.

## 4. At the track

* **Mount** the phone rigidly: a proper dash/roll-bar/windscreen-base mount or Velcro to a flat panel. A suction cup on
  a flexing windscreen adds vibration to every channel. Keep it out of the airbag path and your line of sight, and ask
  the organiser what they allow in the cabin. A loose phone is a projectile at 1.4 g.
* **Heat**: a hot cabin plus screen plus GPS can overheat a phone. Keep it out of direct sun, remove thick cases,
  lower the brightness, start with a full battery, switch Battery Saver off.
* **Each session**: park, START, stay still for the 5 second countdown (engine idling is fine), drive, park, STOP & SAVE.
  Wait for SAVED before you press START again. Leave the app in front with the screen on: that is the most reliable setting.
* Never touch the phone while driving. One session per outing keeps the files short.
* **If the app is killed or the screen says NOT SAVED**: reopen it and tap *Re-export last session*. The recording is
  flushed to the app's private folder every second, so at most the last second is lost.
* **Backup**: run an established lap-timing app (RaceChrono, TrackAddict, Harry's LapTimer...) at the same time. Two apps can
  use the same sensors, and one of them will have been tested on thousands of cars.

## 5. Analyse a session

```
pip install numpy matplotlib
python analysis/analyze.py session_20261013_093012.csv
python analysis/analyze.py session_20261013_093012.csv --sf 2.7608,101.7380    # optional start/finish line
```

(`--sf` takes the latitude,longitude of the start/finish line, for example from a long press in Google Maps.
Without it laps are cut at the fastest point of the session, which is fine for comparing laps.)

It writes, next to the CSV: `report.md`, `channels.csv`, `lap_table.csv`, `corner_table.csv`, `fig_best_lap.png`,
`fig_corners.png`, `fig_laps.png`, `fig_gg.png`, `fig_map.png`.

How the channels are made:

* **up** and **gyro bias** come from the 5 seconds you sat still.
* **forward axis** is found by regressing the phone's horizontal acceleration against the GPS speed derivative, so the
  mount angle does not matter. The report prints R2 (should be close to 1) and the GPS time lag.
* **long. g** = acceleration along that axis: negative is braking, positive is throttle.
* **lateral g** = acceleration across it (left positive). **Curvature** = yaw rate / speed, proportional to wheel angle.
* **speed** = GPS Doppler speed combined with the integrated accelerometer (Kalman filter and smoother).
* Report check: lateral g from the accelerometer against speed x yaw rate from the gyro. They should agree within
  5-10 % (the rest is body roll and mount flex).

Tested on simulated sessions (11 minutes, 5.3 km lap, 4 flying laps, random mount angle, noise, GPS lag, GPS dropout):
forward axis within 0.5 degrees, speed error 0.06 m/s rms, long. g error 0.02 g, curvature error 2 %, lap times
within 0.03 s. It also copes with a sensor clock that differs from the GPS clock, a GPS fix stamped before START, and a
failed calibration. These tests use my own model of the sensors, so they check the maths, not the phone.

## 6. What it cannot do

* **Pedals are not measured.** "Brake" and "throttle" are the car's deceleration and acceleration. Coasting at 0 g is off
  both pedals; once the car is power-limited, 70 % and 100 % throttle look alike.
* **GPS is about 1 Hz.** The 100 Hz traces between fixes come from the inertial sensors. Position (the map, lap line)
  is good to a few metres.
* A phone is not a calibrated logger. Use it for shapes, timings and consistency between laps, not for absolute
  engineering numbers. Body roll and pitch leak a little into the lateral and longitudinal channels.
* If the car never stands still at the start of a session, the orientation falls back to estimates that can be
  10-15 degrees off. Always start parked.

## 7. What was and was not tested

Tested, on a PC:

* The app compiles against the Android 13 and Android 10 interfaces (the second catches use of anything newer than the
  minimum), converts to dex, and the APK's signature, alignment and manifest were verified.
* The recording, the background service and the export to Downloads ran 123 automated checks against a simulated
  Android that I wrote. They cover the file format and row counts, 100 Hz timing, the calibration (also with an odd
  sensor clock, and with too little data), write errors and a full disk, 120 repeated stop cycles with a backlog,
  START pressed during a save, double taps, the system tearing the service down, failed exports leaving no half-written
  file, and the wake lock being released exactly once. The screen code (MainActivity) is not covered by these tests.
* All the source files had an independent review for problems that only show up on a device (permission flow,
  foreground-service rules, the export to Downloads, time bases). It found real bugs, for example a START pressed
  during the save could end the new recording, and they are fixed in 1.2.
* The analysis script ran on simulated sessions, including a phone with a different sensor clock, a GPS fix stamped
  before START and a failed calibration.

Not tested, because it needs a real phone: the permission dialogs, the foreground service surviving a locked screen
and your phone maker's battery manager, the real Downloads export, and how your phone's sensors and GPS actually behave.
Section 3 is how to find out.

## 8. Rebuilding from source

```
./fetch_tools.sh                       # downloads ~170 MB of build tools from GitHub
TOOLS="$PWD/tools" ./build.sh          # javac -> D8 -> aapt2 -> zipalign + sign
```

Output: `build/signed/*.apk`. `build.sh` makes a throwaway signing key `tracklogger.jks` (password `tracklog`) the first time.
An APK signed with a different key cannot be installed over this one: uninstall first (exports in Downloads survive).
